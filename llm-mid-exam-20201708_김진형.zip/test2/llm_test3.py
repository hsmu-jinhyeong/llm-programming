import streamlit as st
from openai import OpenAI
from dotenv import load_dotenv
import os
import fitz  # pymupdf
from io import BytesIO
from docx import Document

# --------------------------
# 환경 변수 로드
# --------------------------
load_dotenv()
api_key = os.getenv('OPENAI_API_KEY')

# --------------------------
# Streamlit UI
# --------------------------
st.set_page_config(page_title="PDF 요약 앱", page_icon="📄")
st.title("📄 PDF 요약 어플리케이션")

st.markdown(
    """
    - PDF 파일을 업로드하면 텍스트를 추출하고 요약합니다.
    - 텍스트 길이가 1000자 미만이면 원본을 출력합니다.
    - 요약 결과는 DOCX 파일로 다운로드 가능합니다.
    """
)

# --------------------------
# PDF 업로드
# --------------------------
uploaded_file = st.file_uploader("PDF 파일 업로드", type=["pdf"])

if uploaded_file is not None:
    # PDF 열기
    try:
        doc = fitz.open(stream=uploaded_file.read(), filetype="pdf")
    except Exception as e:
        st.error(f"PDF 파일 열기 실패: {e}")
        st.stop()

    # --------------------------
    # 텍스트 추출 (헤더/푸터 제외)
    # --------------------------
    full_text = ""
    header_height = 80
    footer_height = 80

    for page in doc:
        rect = page.rect
        text = page.get_text(clip=(0, header_height, rect.width, rect.height - footer_height))
        full_text += text + '\n------------------------------------\n'

    st.markdown("### PDF에서 추출된 텍스트 일부")
    st.text(full_text[:500] + ("..." if len(full_text) > 500 else ""))

    # --------------------------
    # 텍스트 길이 체크
    # --------------------------
    if len(full_text) < 1000:
        st.info("요청한 문서가 짧아 요약 대신 원본 텍스트를 출력합니다.")
        summary_text = full_text
    else:
        # --------------------------
        # GPT 요약
        # --------------------------
        if not api_key:
            st.warning("API Key가 필요합니다. 환경 변수나 .env 파일에 OPENAI_API_KEY를 설정해주세요.")
            st.stop()

        client = OpenAI(api_key=api_key)

        system_prompt = f"""
        너는 다음 글을 요약하는 봇이다. 아래 글을 읽고, 저자의 문제 인식과 주장을 파악하고, 주요 내용을 요약하라.

        작성해야 하는 포맷은 다음과 같다: 

        # 제목

        ## 저자의 문제 인식 및 주장 (15문장 이내)

        ## 저자 소개

        =============== 이하 텍스트 ===============

        {full_text}
        """

        with st.spinner("GPT 요약 생성 중..."):
            response = client.chat.completions.create(
                model="gpt-4o",
                temperature=0.1,
                messages=[{"role": "system", "content": system_prompt}]
            )

        summary_text = response.choices[0].message.content

    # --------------------------
    # 요약 결과 표시
    # --------------------------
    st.markdown("### 요약 결과")
    st.text(summary_text[:1000] + ("..." if len(summary_text) > 1000 else ""))

    # --------------------------
    # DOCX 다운로드 버튼
    # --------------------------
    docx_buffer = BytesIO()
    docx_file = Document()
    docx_file.add_paragraph(summary_text)
    docx_file.save(docx_buffer)
    docx_buffer.seek(0)

    st.download_button(
        label="💾 요약 결과 DOCX 다운로드",
        data=docx_buffer,
        file_name="pdf_summary.docx",
        mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )
else:
    st.info("PDF 파일을 업로드하면 요약을 시작합니다.")
