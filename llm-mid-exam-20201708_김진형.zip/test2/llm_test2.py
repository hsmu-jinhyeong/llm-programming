import streamlit as st
from openai import OpenAI
from dotenv import load_dotenv
import os
import base64

# --------------------------
# 환경 변수 로드
# --------------------------
load_dotenv()
open_api_key = os.getenv("OPENAI_API_KEY")

# --------------------------
# 페이지 설정
# --------------------------
st.set_page_config(page_title="멀티모달 컨텍스트 비교 에이전트", page_icon="🖼️")

# --------------------------
# 세션 초기화
# --------------------------
if "messages" not in st.session_state:
    st.session_state["messages"] = [
        {"role": "assistant", "content": "안녕하세요 🖼️ 저는 멀티모달 컨텍스트 비교 에이전트입니다. 이미지와 관련된 질문을 해보세요."}
    ]

if "uploaded_images" not in st.session_state:
    st.session_state["uploaded_images"] = []  # Base64로 저장

# --------------------------
# 사이드바
# --------------------------
with st.sidebar:
    st.header("💡 챗봇 옵션")

    # 이미지 업로드
    uploaded_files = st.file_uploader(
        "최대 3개의 이미지를 업로드하세요",
        type=["png", "jpg", "jpeg"],
        accept_multiple_files=True
    )

    # Base64로 인코딩 후 세션에 저장
    for file in uploaded_files:
        if len(st.session_state["uploaded_images"]) >= 3:
            st.warning("최대 3개의 이미지만 업로드할 수 있습니다.")
            break
        if file.name not in [img["name"] for img in st.session_state["uploaded_images"]]:
            img_bytes = file.read()
            img_b64 = base64.b64encode(img_bytes).decode("utf-8")
            st.session_state["uploaded_images"].append({"name": file.name, "b64": img_b64})

    # 현재 업로드된 이미지 표시
    if st.session_state["uploaded_images"]:
        st.markdown("### 현재 업로드된 이미지")
        for img in st.session_state["uploaded_images"]:
            st.image(base64.b64decode(img["b64"]), caption=img["name"], use_column_width=True)

    st.markdown("---")


# --------------------------
# 메인 타이틀
# --------------------------
st.title("🖼️ 멀티모달 컨텍스트 비교 에이전트")

# --------------------------
# 기존 대화 출력
# --------------------------
for msg in st.session_state["messages"]:
    st.chat_message(msg["role"]).write(msg["content"])

# --------------------------
# 사용자 입력 처리
# --------------------------
if prompt := st.chat_input("질문을 입력하세요. 예: 이미지들을 분석해줘"):
    st.session_state["messages"].append({"role": "user", "content": prompt})
    st.chat_message("user").write(prompt)

    if not open_api_key:
        st.warning("API Key가 필요합니다. 환경 변수나 .env 파일에 OPENAI_API_KEY를 설정해주세요.")
        st.stop()

    # GPT 시스템 프롬프트 구성
    system_prompt = f"""
    당신은 보안 강화 이미지 챗봇입니다.
    사용자가 업로드한 이미지들을 기억하고, 멀티턴 대화에서 이미지 정보를 유지합니다.
    이미지 정보는 Base64로 인코딩되어 있습니다.
    요청: 업로드된 이미지들의 차이점을 분석하고 가장 특징적인 3가지 요소를 Markdown 표로 출력하세요.
    음식 사진이 아닌 것이 있다면, 그 배경색을 묘사하세요.
    """

    # 이미지 정보 문자열로 변환
    image_descriptions = "\n".join(
        [f"- {img['name']}: {img['b64'][:30]}... (Base64)" for img in st.session_state["uploaded_images"]]
    )

    # GPT 메시지 구성
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"업로드된 이미지 리스트:\n{image_descriptions}\n질문: {prompt}"},
    ]

    # 이전 대화 기록 유지
    for msg in st.session_state["messages"]:
        if msg["role"] != "user":
            messages.append(msg)

    # GPT API 호출
    client = OpenAI(api_key=open_api_key)
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=messages,
        temperature=0.7
    )

    answer = response.choices[0].message.content

    # 응답 저장 및 표시
    st.session_state["messages"].append({"role": "assistant", "content": answer})
    st.chat_message("assistant").write(answer)
