import streamlit as st
from openai import OpenAI
from dotenv import load_dotenv
import os

# --------------------------
# 환경 변수 로드
# --------------------------
load_dotenv()
open_api_key = os.getenv("OPENAI_API_KEY")
FORBIDDEN_KEYWORD = os.getenv("FORBIDDEN_KEYWORD", "투자,주식,도박")
forbidden_list = [kw.strip() for kw in FORBIDDEN_KEYWORD.split(",") if kw.strip()]

# --------------------------
# Streamlit 페이지 설정
# --------------------------
st.set_page_config(page_title="보안 강화 챗봇 에이전트", page_icon="🛡️")
st.title("🛡️ 보안 강화 챗봇 에이전트")

# --------------------------
# 사이드바
# --------------------------
with st.sidebar:
    st.header("💡 챗봇 옵션")

    # 창의성 레벨 선택
    temp_level = st.selectbox(
        "창의성 레벨 선택:",
        ["보수적 (0.2)", "보통 (0.7)", "창의적 (1.0)"]
    )
    temperature = {"보수적 (0.2)": 0.2, "보통 (0.7)": 0.7, "창의적 (1.0)": 1.0}[temp_level]

    st.markdown(f"**현재 온도:** {temperature}")
    st.markdown(f"**방어 키워드:** {', '.join(forbidden_list) if forbidden_list else '없음'}")

# --------------------------
# 세션 초기화
# --------------------------
if "messages" not in st.session_state:
    st.session_state["messages"] = [
        {
            "role": "assistant",
            "content": "안녕하세요 🛡️ 저는 보안 강화 챗봇 에이전트입니다. 오늘은 어떤 이야기를 나누고 싶으신가요?",
        }
    ]

# --------------------------
# 기존 대화 출력
# --------------------------
for msg in st.session_state.messages:
    st.chat_message(msg["role"]).write(msg["content"])

# --------------------------
# 사용자 입력 처리
# --------------------------
if prompt := st.chat_input("질문을 입력하세요..."):
    # 사용자 메시지 저장 및 출력
    st.session_state.messages.append({"role": "user", "content": prompt})
    st.chat_message("user").write(prompt)

    # --------------------------
    # 방어 키워드 체크 (소문자 통일)
    # --------------------------
    prompt_lower = prompt.lower()
    if any(kw.lower() in prompt_lower for kw in forbidden_list):
        response_text = "죄송합니다. 저는 금융 및 투자 상담을 할 수 없습니다."
        st.session_state.messages.append({"role": "assistant", "content": response_text})
        st.chat_message("assistant").write(response_text)
    else:
        # --------------------------
        # OpenAI API 호출
        # --------------------------
        if not open_api_key:
            st.warning("API Key가 필요합니다. .env 파일에 OPENAI_API_KEY를 설정해주세요.")
            st.stop()

        system_prompt = f"""
        당신은 보안 강화 챗봇 에이전트입니다.
        사용자의 고민을 따뜻하게 공감하고, 필요할 때 창의적이고 현실적인 조언을 제공합니다.
        창의성 레벨: {temp_level}
        """

        client = OpenAI(api_key=open_api_key)
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "system", "content": system_prompt}] + st.session_state.messages,
            temperature=temperature
        )

        # GPT 응답 저장 및 출력
        msg = response.choices[0].message.content
        st.session_state.messages.append({"role": "assistant", "content": msg})
        st.chat_message("assistant").write(msg)
